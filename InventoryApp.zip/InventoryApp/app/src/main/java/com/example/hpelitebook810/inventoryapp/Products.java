package com.example.hpelitebook810.inventoryapp;

public interface Products {
    void update();
}