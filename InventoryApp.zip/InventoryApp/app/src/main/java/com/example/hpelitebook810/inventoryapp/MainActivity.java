package com.example.hpelitebook810.inventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.hpelitebook810.inventoryapp.data.ProductDbOpenHelper;

public class MainActivity extends AppCompatActivity implements Products {

    ProductDbOpenHelper helper;
    SQLiteDatabase db;
    private Cursor cursor;
    ProductCursorAdapter itemAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        helper = ProductDbOpenHelper.getInstance(this);
        helper.addObserver(this);

        cursor = helper.getAllProducts();

        ListView listView = (ListView) findViewById(R.id.list);

        itemAdapter = new ProductCursorAdapter(MainActivity.this, cursor, 0);

        listView.setAdapter(itemAdapter);
        listView.setItemsCanFocus(false);

        TextView defaultText = (TextView) findViewById(R.id.i_empty);
        listView.setEmptyView(defaultText);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
                cursor.moveToPosition(position);
                String name = cursor.getString(cursor.getColumnIndexOrThrow("product_name"));
                intent.putExtra("name_to_display", name);
                startActivity(intent);
            }
        });

        Button addProduct = (Button) findViewById(R.id.add_main_activity);
        addProduct.setOnClickListener(handleAddProduct);
    }

    View.OnClickListener handleAddProduct = new View.OnClickListener() {
        public void onClick(View v) {
            Intent bIntent = new Intent(MainActivity.this, ProductActivity.class);
            startActivity(bIntent);
        }
    };

    @Override
    public void update() {
        if (cursor != null) {
            Cursor newCursor = helper.getAllProducts();
            itemAdapter.swapCursor(newCursor);
        }
    }
}