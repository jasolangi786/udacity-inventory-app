package com.example.hpelitebook810.inventoryapp;

public interface Observable{
    void addObserver(Products o);
    void removeObserver(Products o);
    void notifyObservers();
}