package com.example.hpelitebook810.inventoryapp.data;


import android.provider.BaseColumns;

public class ProductContract {

    public ProductContract() {}

    public static abstract class Products implements BaseColumns {
        public static final String TABLE_NAME = "products";
        public static final String PNAME = "product_name";
        public static final String PRICE = "price";
        public static final String QTY = "quantity";
        public static final String SNAME = "supplier_name";
        public static final String EMAIL = "email";
        public static final String IMAGE = "image";
    }
}