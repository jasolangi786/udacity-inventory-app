package com.example.hpelitebook810.inventoryapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.hpelitebook810.inventoryapp.data.ProductDbOpenHelper;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;

public class ProductActivity extends AppCompatActivity {

    private static int ACTIVITY_SELECT_IMAGE = 1;

    ProductDbOpenHelper helper;
    String newName;
    double newPrice;
    int newQuantity;
    String newSupplierName;
    String newSupplierEmail;
    boolean canAdd = false;
    byte[] imageInByte;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_product);
        helper = ProductDbOpenHelper.getInstance(this);

        Button buttonLoadImage = (Button) findViewById(R.id.add_product_image);
        buttonLoadImage.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                Intent intent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, ACTIVITY_SELECT_IMAGE);
            }
        });

        Button addProduct = (Button) findViewById(R.id.add_product_button);
        addProduct.setOnClickListener(handleAddNewProduct);
    }

    View.OnClickListener handleAddNewProduct = new View.OnClickListener() {
        public void onClick(View v) {
            newName = getNewProductName();
            newPrice = getNewProductPrice();
            newQuantity = getNewProductQty();
            newSupplierName = getNewSupplierName();
            newSupplierEmail = getNewSupplierEmail();

            if (newName.equals("") || newPrice == 0 || newSupplierName.equals("") || newSupplierEmail.equals("") || imageInByte == null) {
                Toast.makeText(ProductActivity.this, "Please, enter full information about the product.",
                        Toast.LENGTH_LONG).show();
            } else canAdd = true;

            if (canAdd) {
                helper.addProduct(new Product(newName, newPrice, newQuantity, newSupplierName, newSupplierEmail, imageInByte));
                Intent intent = new Intent(ProductActivity.this, MainActivity.class);
                startActivity(intent);
            }
        }
    };

        public String getNewProductName() {
        EditText name = (EditText) findViewById(R.id.enter_product_name);
        try {
            return name.getText().toString();
        } catch (NumberFormatException e) {
            Log.v("Name: ", "Could not parse name");
            return "";
        }
    }

    public double getNewProductPrice() {
        EditText price = (EditText) findViewById(R.id.enter_product_price);
        try {
            return Double.parseDouble(price.getText().toString());
        } catch (NumberFormatException e) {
            Log.v("Price: ", "Could not parse price");
            return 0;
        }
    }

    public int getNewProductQty() {
        EditText qty = (EditText) findViewById(R.id.enter_product_quantity);
        try {
            return Integer.parseInt(qty.getText().toString());
        } catch (NumberFormatException e) {
            Log.v("Quantity: ", "Could not parse quantity");
            return 0;
        }
    }

    public String getNewSupplierName() {
        EditText supplierName = (EditText) findViewById(R.id.enter_product_supplier);
        try {
            return supplierName.getText().toString();
        } catch (NumberFormatException e) {
            Log.v("Supplier: ", "Could not parse supplier");
            return "";
        }
    }

    public String getNewSupplierEmail() {
        EditText email = (EditText) findViewById(R.id.add_product_email);
        try {
            return email.getText().toString();
        } catch (NumberFormatException e) {
            Log.v("Supplier email: ", "Could not parse supplier email");
            return "";
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ACTIVITY_SELECT_IMAGE && resultCode == RESULT_OK && null != data) {
            Uri selectedImage = data.getData();

            try {
                Bitmap yourSelectedImage = decodeUri(selectedImage);
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                yourSelectedImage.compress(Bitmap.CompressFormat.PNG, 100, stream);
                imageInByte = stream.toByteArray();

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    private Bitmap decodeUri(Uri selectedImage) throws FileNotFoundException {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(getContentResolver().openInputStream(selectedImage), null, options);

        final int REQUIRED_SIZE = 140;

        int width = options.outWidth, height = options.outHeight;
        int scale = 1;
        while (true) {
            if (width / 2 < REQUIRED_SIZE || height / 2 < REQUIRED_SIZE) {
                break;
            }
            width /= 2;
            height /= 2;
            scale *= 2;
        }
        BitmapFactory.Options options2 = new BitmapFactory.Options();
        options2.inSampleSize = scale;
        return BitmapFactory.decodeStream(getContentResolver().openInputStream(selectedImage), null, options2);
    }
}